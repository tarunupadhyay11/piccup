import axios from 'axios';


export default axiosInstance = axios.create({
    baseURL: 'http://piccupkw.com/mobileApi/',
    timeout: 3000,
  });